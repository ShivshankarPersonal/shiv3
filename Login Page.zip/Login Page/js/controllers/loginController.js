(function () {
    angular.module("dashboard")
        .controller("loginController", function ($scope, dashboardFactory, $location) {
            $scope.showPuzzleArea = false;
            $scope.userFieldError = false;
            $scope.loginDisable = true;
            $scope.showCompleError = false;

            $scope.onUserNameEnter = function ($event) {
                dashboardFactory.getUserDetails().then(function (data, status, headers, config) {
                    $scope.userDetails = data.users;
                    for (var i = 0; i < data.users.length; i++) {
                        if ($scope.userName === data.users[i].username || $scope.userName === data.users[i].emalID) {
                            $scope.showPuzzleArea = true;
                            $scope.userFieldError = false;
                            if($scope.password && $scope.userName){
                                $scope.loginDisable = false;
                            }
                            $scope.$emit("startCountDown", {});
                            return;
                        } else {
                            $scope.userFieldError = true;
                        }
                    }

                }, function (data, status, headers, config) {
                    console.error("error", data);
                })
                if($scope.password && $scope.userName){
                    $scope.loginDisable = false;
                }

            };

            $scope.onPasswordEnter = function () {
                if($scope.password && $scope.userName){
                    $scope.loginDisable = false;
                }

            };

            $scope.onLoginClick = function () {
                for (var i = 0; i < $scope.userDetails.length; i++) {
                    if (($scope.userName === $scope.userDetails[i].username || $scope.userName === $scope.userDetails[i].emalID) && ($scope.password === $scope.userDetails[i].password )) {
                        sessionStorage.setItem('loginId',$scope.userName);
                        $scope.logoutBtn = true;
                        $location.path("/video_dashboard");
                        $scope.showCompleError = false;
                    }else{
                        $scope.showCompleError = true;
                    }
                }
            }
        });
})();


