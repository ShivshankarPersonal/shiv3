(function () {

    angular.module("dashboard")

        .controller("videoDashboard", function ($scope,$location) {
            $scope.greeting = "Video Dashboard";
            if (!sessionStorage.getItem('loginId')) {
                $location.path("/login");
            }
            $scope.logoutBtn = true;
            $scope.onLogout = function(){
                $location.path("/login");
                sessionStorage.removeItem('loginId');
            }



        });
})();
