(function(){

    angular.module("dashboard")

        .controller("graphsDashboard",function($scope){
            $scope.greeting = "Graphs Dashboard"
        });
})();