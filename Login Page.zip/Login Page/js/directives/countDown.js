(function () {
    "use strict";
    angular.module("countDown", [])
        .directive("countDown", function () {
            return {
                restrict: "E",
                templateUrl: "templates/countDown.html",
                link: function ($scope, element, attrs) {
                    $scope.$on("startCountDown", function () {

                        var time = 10;
                        var initialOffset = '440';
                        var i = 1;
                        //$('.circle_animation').css('stroke-dashoffset', initialOffset - (1 * (initialOffset / time)));
                        angular.element(document.getElementsByClassName('circle_animation')).css('stroke-dashoffset', initialOffset - (1 * (initialOffset / time)));
                        var interval = setInterval(function () {
                            //$('p#countDown').append("<span>Seconds</span>").text(i);
                            angular.element(document.getElementById('countDown')).append("<span>Seconds</span>").text(i);
                            if (i == time) {
                                clearInterval(interval);
                                return;
                            }
                            //$('.circle_animation').css('stroke-dashoffset', initialOffset - ((i + 1) * (initialOffset / time)));
                            angular.element(document.getElementsByClassName('circle_animation')).css('stroke-dashoffset', initialOffset - ((i + 1) * (initialOffset / time)));
                            i++;
                        }, 1000);
                    });
                }
            }
        })
})();