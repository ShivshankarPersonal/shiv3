(function () {
    'use strict';
    angular.module("dashboard", ['ngRoute','countDown'])

        .config(function ($routeProvider) {
            $routeProvider
                .when('/login', {
                    templateUrl: 'templates/loginPage.html',
                    controller: 'loginController'
                })
                .when('/video_dashboard', {
                    templateUrl: 'templates/videoDashboard.html',
                    controller: 'videoDashboard'
                })
                .when('/graphs_dashboard', {
                    templateUrl: 'templates/graphsDashboard.html',
                    controller: 'graphsDashboard'
                })
                .otherwise({
                    redirectTo: '/login'
                })

        });
})();





